/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.InterFace;

import Database.DbConnection;
import java.awt.Color;
import java.awt.Toolkit;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import office.Entities.Converter;
import office.Entities.Group;
import office.Entities.Period;
import office.Entities.Student;

/**
 *
 * @author Omar Ahmed
 */
public class StartInterface extends javax.swing.JFrame {

    ArrayList<Student> students = new ArrayList<>();
    Group group;

    /**
     * Creates new form StartInterface
     */
    public StartInterface() {
          if (!isFileshipAlreadyRunning()) {
            JOptionPane.showMessageDialog(this, "the programe is already running");
            System.exit(0);
            return;
        }
          SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
          String date = sd.format(new Date());
          String total[] = date.split("-");
         int year=Integer.parseInt(total[0]);
                  int month=Integer.parseInt(total[1]);
         int day=Integer.parseInt(total[2]);
         


        this.setUndecorated(true);//Remove title bar
        // this.setAlwaysOnTop(true);
        this.setResizable(false);
        initComponents();
        Toolkit tk = Toolkit.getDefaultToolkit();
        int xSize = (int) tk.getScreenSize().getWidth();
        int ySize = (int) tk.getScreenSize().getHeight();
        this.setSize(xSize, ySize);

        // set Buttons hovers
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2.setBackground(new java.awt.Color(239, 91, 43));
            }
        });

        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1.setBackground(new java.awt.Color(239, 91, 43));
            }
        });

        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton4.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton4.setBackground(new java.awt.Color(239, 91, 43));
            }
        });

        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton3.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton3.setBackground(new java.awt.Color(239, 91, 43));
            }
        });

        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton7.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton7.setBackground(new java.awt.Color(239, 91, 43));
            }
        });

        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton5.setBackground(new java.awt.Color(51, 102, 255));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton5.setBackground(new java.awt.Color(239, 91, 43));
            }
        });

        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton6.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6.setBackground(new java.awt.Color(239, 91, 43));
            }
        });
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton9.setBackground(Color.GREEN);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton9.setBackground(new java.awt.Color(239, 91, 43));
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        Search_buttons = new javax.swing.ButtonGroup();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        Search = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        phone = new javax.swing.JRadioButton();
        id = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        day = new javax.swing.JComboBox();
        month = new javax.swing.JComboBox();
        year = new javax.swing.JComboBox();
        name = new javax.swing.JRadioButton();
        ComboBox = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        jLabel3.setForeground(new java.awt.Color(51, 153, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/office/InterFace/back.jpg"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setBackground(new java.awt.Color(239, 91, 43));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("الغياب");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(1170, 290, 220, 50);

        jButton2.setBackground(new java.awt.Color(239, 91, 43));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("بحث عن مجموعة");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(1170, 170, 220, 50);

        jButton3.setBackground(new java.awt.Color(239, 91, 43));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("تقرير عن حصة");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(1170, 530, 220, 50);

        jButton4.setBackground(new java.awt.Color(239, 91, 43));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("اضافة مجموعة جديدة");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(1170, 410, 220, 50);

        Search.setBackground(new java.awt.Color(212, 213, 224));
        Search.setName("Search"); // NOI18N
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        getContentPane().add(Search);
        Search.setBounds(430, 370, 310, 30);

        jButton5.setBackground(new java.awt.Color(239, 91, 43));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("بحث");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(270, 370, 80, 30);

        jButton6.setBackground(new java.awt.Color(239, 91, 43));
        jButton6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Close");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6);
        jButton6.setBounds(60, 650, 220, 50);

        Search_buttons.add(phone);
        phone.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        phone.setText("رقم الهاتف");
        getContentPane().add(phone);
        phone.setBounds(650, 410, 90, 25);

        Search_buttons.add(id);
        id.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        id.setText("رقم الطالب");
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(440, 410, 100, 25);
        getContentPane().add(jLabel1);
        jLabel1.setBounds(100, 0, 70, 80);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/office/InterFace/searchIcon.png"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(740, 370, 40, 30);

        jButton7.setBackground(new java.awt.Color(239, 91, 43));
        jButton7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("أدخل الدرجات");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7);
        jButton7.setBounds(1170, 650, 220, 50);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("ابحث عن الحصص");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(770, 310, 210, 22);

        jLabel8.setText("اليوم");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(710, 310, 34, 14);

        jLabel9.setText("الشهر");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(610, 310, 29, 14);

        jLabel10.setText("السنة");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(510, 310, 28, 14);

        jButton9.setBackground(new java.awt.Color(239, 91, 43));
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("بحث");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton9);
        jButton9.setBounds(270, 310, 80, 30);

        day.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        getContentPane().add(day);
        day.setBounds(650, 310, 50, 20);

        month.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        getContentPane().add(month);
        month.setBounds(550, 310, 50, 20);

        year.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "2017", "2018", "2019", "2020", " " }));
        year.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearActionPerformed(evt);
            }
        });
        getContentPane().add(year);
        year.setBounds(430, 310, 70, 20);

        Search_buttons.add(name);
        name.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        name.setText("الاسم");
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        getContentPane().add(name);
        name.setBounds(560, 410, 70, 25);

        ComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }));
        getContentPane().add(ComboBox);
        ComboBox.setBounds(450, 450, 90, 20);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/office/InterFace/newBackground.jpg"))); // NOI18N
        jLabel11.setText("jLabel11");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(-230, 0, 1600, 770);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/office/InterFace/crop.png"))); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(1342, 494, 190, 280);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/office/InterFace/crop.png"))); // NOI18N
        getContentPane().add(jLabel5);
        jLabel5.setBounds(1370, -120, 80, 620);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new Options().setVisible(true);

        // this.dispose();//to close the current jframe
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        new AddGroup().setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed

    }//GEN-LAST:event_SearchActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        System.exit(0); // To close programme 
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new periodLesson().setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        int z = 0;
                    char c;

        try {
c =JOptionPane.showInputDialog(this, "ادخل رمز المجموعة").charAt(0);
          z= Converter.Numric(c+"");
        // z = Integer.parseInt(JOptionPane.showInputDialog(this, "ادخل رمز المجموعة"));
            System.out.println(z+"zzzzzzz");
            group = DbConnection.selectGroup(z);
            if (group == null) {
                JOptionPane.showMessageDialog(this, "مفيش جروب بالرقم ده");
                return;
            } else {
                students = DbConnection.selectByGroup(z);

            }

        } catch (Exception E) {
            return;
        }

        /*
         new DataTable(students);    }                                        
         */
        StudentAttend st = null;
        try {
            st = new StudentAttend(students,c);
        } catch (Exception ex) {
        }
        try {
            new DataTable(students, st, z,c);
        } catch (Exception ex) {
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        Student s;
        Group g = null;
        int x;
        if (name.isSelected()) {
            try {
                s = DbConnection.selecBytName(Search.getText().trim());
                if (s != null) {
                    new StudentInfo(s);
                } else {
                    JOptionPane.showMessageDialog(this, "مفيش طالب بالاسم ده");
                }
            } catch (Exception ex) {

            }

        } else if (phone.isSelected()) {
            try {
                s = DbConnection.selecByPhone(Search.getText().trim());
                if (s != null) {
                    new StudentInfo(s);
                } else {
                    JOptionPane.showMessageDialog(this, "رقم التليفون غلط");
                }
            } catch (Exception ex) {

            }
        } else if (id.isSelected()) {
            try {
                x = Integer.parseInt(Search.getText().trim());
                String gp=Converter.Numric(ComboBox.getSelectedItem()+"")+"";
                String number = gp+""+x;
                 try {
                 g =DbConnection.selectGroup(Converter.Numric(ComboBox.getSelectedItem().toString()));
            } catch (Exception ex) {
                
                
            }
            if (g==null)
            {
                  
                   

                JOptionPane.showMessageDialog(this, "لا يوجد مجموعة بهذا الرقم");
                
                return;
            }
                s = DbConnection.selecBytId(Integer.parseInt(number));
                if (s != null) {
                    new StudentInfo(s);
                } else {
                    JOptionPane.showMessageDialog(this, "رقم الطالب غلط");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,"دخل ارقام بس");
            }
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        new MonthExam().setVisible(true);
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        ArrayList<Period> lessons;
        String days, months, years;
        days = (String) day.getSelectedItem();
        months = (String) month.getSelectedItem();
        years = (String) year.getSelectedItem();
        String date = years + "/" + months + "/" + days;
        System.out.println(date);
        try {
            lessons = DbConnection.selectAllLesson(date);
            System.out.println(lessons.size());
            new LessonTable(lessons);

        } catch (Exception ex) {

        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void yearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_yearActionPerformed
private static boolean isFileshipAlreadyRunning() {
    // socket concept is shown at http://www.rbgrn.net/content/43-java-single-application-instance
        // but this one is really great
        try {
            final File file = new File("FileshipReserved.txt");
            final RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
            final FileLock fileLock = randomAccessFile.getChannel().tryLock();
            if (fileLock != null) {
                Runtime.getRuntime().addShutdownHook(new Thread() {
                    public void run() {
                        try {
                            fileLock.release();
                            randomAccessFile.close();
                            file.delete();
                        } catch (Exception e) {
                            //log.error("Unable to remove lock file: " + lockFile, e);
                        }
                    }
                });
                return true;
            }
        } catch (Exception e) {
            // log.error("Unable to create and/or lock file: " + lockFile, e);
        }
        return false;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StartInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StartInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StartInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StartInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StartInterface().setVisible(true);

            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox ComboBox;
    private javax.swing.JTextField Search;
    private javax.swing.ButtonGroup Search_buttons;
    private javax.swing.JComboBox day;
    private javax.swing.JRadioButton id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JComboBox month;
    private javax.swing.JRadioButton name;
    private javax.swing.JRadioButton phone;
    private javax.swing.JComboBox year;
    // End of variables declaration//GEN-END:variables
}
