/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Entities;

/**
 *
 * @author Omar Ahmed
 */
public class Student {
    int Id,NumberOfBookTook,GroupNumber,Pay,BookPay,groupAttend;
    String Phone,name,Whats,Division,ParentPhone,Email,Notes,School;
    boolean bookChecked;
    Period pe;
    public Student(int Id, int NumberOfBookTook, int Pay, int BookPay, String Phone, String name, String Whats, String Division, String ParentPhone, String Email, String Notes,int group,String school,boolean check) {
        this.Id = Id;
        this.NumberOfBookTook = NumberOfBookTook;
        this.Pay = Pay;
        this.BookPay = BookPay;
        this.Phone = Phone;
        this.name = name;
        this.Whats = Whats;
        this.Division = Division;
        this.ParentPhone = ParentPhone;
        this.Email = Email;
        this.Notes = Notes;
        this.GroupNumber =group;
        this.School=school;
        this.bookChecked =check;
    }

    public Student(int Id, String name) {
        this.Id = Id;
        this.name = name;
    }

   
    

    public Student(int Id, int GroupNumber, Period pe) {
        this.Id = Id;
        this.GroupNumber = GroupNumber;
        this.pe = pe;
    }
    public Student(int Id, int GroupNumber, Period pe,int gAttend) {
        this.Id = Id;
        this.GroupNumber = GroupNumber;
        this.pe = pe;
        this.groupAttend= gAttend;
    }
    public Student(int Id, int GroupNumber, Period pe,int gAttend,String n) {
        this.Id = Id;
        this.GroupNumber = GroupNumber;
        this.pe = pe;
        this.groupAttend= gAttend;
        this.name=n;
    }
    public Student (){
        
    }
    
    
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getNumberOfBookTook() {
        return NumberOfBookTook;
    }

    public void setNumberOfBookTook(int NumberOfBookTook) {
        this.NumberOfBookTook = NumberOfBookTook;
    }

    public int getGroupNumber() {
        return GroupNumber;
    }

    public void setGroupNumber(int GroupNumber) {
        this.GroupNumber = GroupNumber;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getWhats() {
        return Whats;
    }

    public void setWhats(String Whats) {
        this.Whats = Whats;
    }

    public int getPay() {
        return Pay;
    }

    public void setPay(int Pay) {
        this.Pay = Pay;
    }

    public String getDivision() {
        return Division;
    }

    public void setDivision(String Division) {
        this.Division = Division;
    }

    public String getParentPhone() {
        return ParentPhone;
    }

    public void setParentPhone(String ParentPhone) {
        this.ParentPhone = ParentPhone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getBookPay() {
        return BookPay;
    }

    public void setBookPay(int BookPay) {
        this.BookPay = BookPay;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String Notes) {
        this.Notes = Notes;
    }

    public boolean isBookChecked() {
        return bookChecked;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBookChecked(boolean bookChecked) {
        this.bookChecked = bookChecked;
    }

    public String getSchool() {
        return School;
    }

    public void setSchool(String School) {
        this.School = School;
    }

    public Period getPe() {
        return pe;
    }

    public int getGroupAttend() {
        return groupAttend;
    }

    public void setGroupAttend(int groupAttend) {
        this.groupAttend = groupAttend;
    }

    public void setPe(Period pe) {
        this.pe = pe;
    }
    
    
}
