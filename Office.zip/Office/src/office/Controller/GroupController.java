/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Controller;

import Database.DbConnection;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import office.Entities.Group;
import office.Entities.Period;

/**
 *
 * @author Omar Ahmed
 */
public class GroupController {
    
    
    public int getLastPeriod(int gpId){
        Group gp=new Group();
        DbConnection db= new DbConnection();
        
        try {
            gp= db.selectGroupLesson(gpId);
            if(gp==null)
                return 0;
            else{
                return gp.getPe().getId();
            }
        } catch (Exception ex) {
            Logger.getLogger(GroupController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return -1;
    }
    
    
    public int getgroup(int gpId){
        // return -1 lma tekon mafish group bl id eli fi el parameters
        
        Group group= null;
        DbConnection db= new DbConnection();
        try {

            group=db.selectGroup(gpId);
            if(group==null){
                return -1;
            }
        } catch (Exception ex) {
            Logger.getLogger(GroupController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }
    
    public Group getGroupInfromation(int gpId){
        // return -1 lma tekon mafish group bl id eli fi el parameters
        
        Group gp=new Group();
        DbConnection db= new DbConnection();
        try {

            gp= db.selectGroupTotal(gpId);
           // System.out.println(gp.getTotalStudent()+"  KKKKK");
            return gp;
            
        } catch (Exception ex) {
            Logger.getLogger(GroupController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return gp;
    }
    
    public boolean insertLessonGroup(int gpId){
        DbConnection db= new DbConnection();
        Group gp=new Group();
        gp.setId(gpId);
        return db.insertGroupLesson(gp);
    }
    
    public boolean updateLessonGroup(int gpId,int perID){
        DbConnection db= new DbConnection();
        Group gp=new Group();
        Period period=new Period();
        period.setId(perID);
        gp.setId(gpId);
        gp.setPe(period);
        try {
            db.updateGroupLesson(gp);
            return true;
        } catch (Exception ex) {
            Logger.getLogger(GroupController.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
}
