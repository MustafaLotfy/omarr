/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Controller;

import Database.DbConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
import office.Entities.Period;

/**
 *
 * @author Omar Ahmed
 */
public class PeriodController {
    
  public Period getLesson(int gpId,int perId){
      
      DbConnection dbConnection=new DbConnection();
      Period per =new Period();
      System.out.println(perId+ "  HHH  "+gpId);
      try {
          per=dbConnection.selectLesson(perId, gpId);
          
//          System.out.println(per.getId());
          if(per!=null){
                return per;
          }
          else{
              per =new Period();
              per.setId(-1);
              return per;
          }
      } catch (Exception ex) {
           
          per.setId(-1);
          
          //Logger.getLogger(PeriodController.class.getName()).log(Level.SEVERE, null, ex);
          return per;
      }
      
  }
  
  public boolean insertLesson(int gpId,int perId,String date){
      
      DbConnection dbConnection=new DbConnection();
      boolean check;
     
      try {
          check=dbConnection.insertLesson(perId, gpId,date);
          
          return check;
      } catch (Exception ex) {
           
          
          
          //Logger.getLogger(PeriodController.class.getName()).log(Level.SEVERE, null, ex);
          return false;
      }
      
  }
  
  public boolean updateCost(double cost,double oldCost,int gpId,int perId){
      Period per = new Period(perId);
      per.setTotalMoney(cost+oldCost);
      
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonCost(per, gpId);
          return true;
      } catch (Exception ex) {
         
          return false;
      }
  }
  
  public boolean updateAttendNum(int AttendNum,int gpId,int perId){
      
     Period per = new Period(perId);
      //System.out.println(AttendNum + "  AttendNum");
      per.setAttendenceNumber(AttendNum+1);
      
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonAttend(per, gpId);
     
          return true;
      } catch (Exception ex) {
      
          return false;
      }
  }
  public boolean updateAbbsent (int totalAttend,int Attend ,int gpId,int perId){
      Period per = new Period(perId);
      
      System.out.println(totalAttend+"       F  "+ Attend);
      per.setAbsence(totalAttend-Attend);
      
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonAbsence(per, gpId);
          return true;
      } catch (Exception ex) {
          
          return false;
      }
     
  }
   public boolean updateAbbsent (int totalAttend,int att,int AnoAttend ,int gpId,int perId){
      Period per = new Period(perId);
      
      System.out.println(totalAttend+"       F  "+ AnoAttend);
      per.setAbsence(totalAttend-att);
      
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonAbsence(per, gpId);
          return true;
      } catch (Exception ex) {
          
          return false;
      }
     
  }
  public boolean updateInAnotherTime(int count,int gpId,int perId){
      Period per = new Period(perId);
      int total=count+1;
      System.out.println(count+"   TESt  "+total);
      per.setAttendInAnotherTime(total);
      System.out.println(per.getAttendInAnotherTime()+"   TESt");
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonAttendAnotherTime(per, gpId);
          return true;
      } catch (Exception ex) {
          return false;
      }
     
  }
    
  public boolean updatePayments(double pay,double oldpay,int gpId,int perId){
      Period per = new Period(perId);
      System.out.println(pay + " PAYMENTS " + oldpay);
      per.setPayment(pay+oldpay);
      
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonPayment(per, gpId);
          return true;
      } catch (Exception ex) {
          return false;
      }
     
  }
  
  public boolean updateNotes(String note,String oldNotes,int gpId,int perId){
       Period per = new Period(perId);
      if(oldNotes!=null) 
        per.setNotes(note+"---"+oldNotes);
      
      else {
        per.setNotes(note);  
      }
      
      DbConnection dbConnection=new DbConnection();
      try {
          dbConnection.updateLessonNotes(per, gpId);
          return true;
      } catch (Exception ex) {
          return false;
      }
     
  }
  
 
}
