/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Entities;

/**
 *
 * @author mohamed
 */
public class Exams {
    int Examid,group;
    double degree,TotalDegree;
    Student student ;
    public Exams() {
    }

    public Exams(int Examid, int group, double degree, double TotalDegree, Student student) {
        this.Examid = Examid;
        this.group = group;
        this.degree = degree;
        this.TotalDegree = TotalDegree;
        this.student = student;
    }
    
    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public int getExamid() {
        return Examid;
    }

    public void setExamid(int Examid) {
        this.Examid = Examid;
    }

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }

    public double getDegree() {
        return degree;
    }

    public void setDegree(double degree) {
        this.degree = degree;
    }

    public double getTotalDegree() {
        return TotalDegree;
    }

    public void setTotalDegree(double TotalDegree) {
        this.TotalDegree = TotalDegree;
    }
    
}
