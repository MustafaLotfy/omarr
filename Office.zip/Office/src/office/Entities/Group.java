/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Entities;

/**
 *
 * @author Omar Ahmed
 */
public class Group {
    int Id ,TotalStudent;
    int Start,End;
    String Date;
    Period pe;
    
    public Group(int Id, int Start, int End, String Date) {
        this.Id = Id;
        this.Start = Start;
        this.End = End;
        this.Date = Date;
    }

    public Group(int Id,Period p) {
        this.Id = Id;
        this.pe = p;
    }
    
    public Group(int totalnum) {
        this.TotalStudent=totalnum;
    }
    
    public Group(){
        
    }
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getTotalStudent() {
        return TotalStudent;
    }

    public void setTotalStudent(int TotalStudent) {
        this.TotalStudent = TotalStudent;
    }

    public int getStart() {
        return Start;
    }

    public void setStart(int Start) {
        this.Start = Start;
    }

    public int getEnd() {
        return End;
    }

    public void setEnd(int End) {
        this.End = End;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public Period getPe() {
        return pe;
    }

    public void setPe(Period pe) {
        this.pe = pe;
    }
    
    
}
