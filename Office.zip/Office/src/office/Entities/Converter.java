/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Entities;

/**
 *
 * @author Omar Ahmed
 */
public class Converter {
    
    public static String Alph(int Num){
        String Alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return Alpha.charAt(Num-1)+"";
    }
    
    public static int Numric(String Char){
    Char=    Char.toUpperCase();
        String Alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for (int i = 0; i < Alpha.length(); i++) {
            if(Char.equals(Alpha.charAt(i)+"")){
                return i+1;
            }
        }
        
        return -1;
    }
}
